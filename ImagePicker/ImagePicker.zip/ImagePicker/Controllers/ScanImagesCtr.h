//
//  ScanImagesCtr.h
//  ImagePicker
//
//  Created by zj on 16/9/21.
//  Copyright © 2016年 zj. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScanImagesCtr : UIViewController
@property(nonatomic,strong) NSMutableArray             *AllImages;
@property(nonatomic,assign) NSUInteger                  SelectedImageNum;



@end
